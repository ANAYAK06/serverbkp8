﻿//Start of Saving Basic Business Info//





//function BindCapitalGrid() {
  
//    var newRow = $("<tr>");
//    var cols = "";
//    cols += '<td style="text-align:center;display:none">1</td><td colspan="3">AUTHORISED CAPITAL</td>'; 
//    newRow.append(cols);
//    var newRow1 = $("<tr>");
//    var cols1 = "";
//    cols1 += '<td class="hidden">2<td>Number Of Shares</td><td>Price Of Each Share</td><td>Amount</td>';
//    newRow1.append(cols1);
//    var newRow2 = $("<tr>");
//    var cols2 = "";
//    cols2+= '<td  class="hidden">3<td><input type="text" class="form-control"  onkeypress="return IsNumeric(event)" id="txtnoofshare"/></td><td><input type="text" class="form-control"  onkeypress = "return ValidateAmount(this,event)"  id="txtpriceofshare"/></td><td><input type="text" class="form-control"  onkeypress = "return ValidateAmount(this,event)"  id="txtCAmount"/></td>';
//    newRow2.append(cols2);

//    var newRow3 = $("<tr>");
//    var cols3 = "";
//    cols3 += '<td style="text-align:center;display:none"">4</td><td colspan="3">ISSUED CAPITAL</td>';
//    newRow3.append(cols3);
//    var newRow4 = $("<tr>");
//    var cols4 = "";
//    cols4 += '<td  class="hidden">5<td>Number Of Shares</td><td>Price Of Each Share</td><td>Amount</td>';
//    newRow4.append(cols4);
//    var newRow5 = $("<tr>");
//    var cols5 = "";
//    cols5 += '<td  class="hidden">6<td><input type="text" class="form-control"  onkeypress="return IsNumeric(event)" id="txtnoofshare"/></td><td><input type="text" class="form-control"  onkeypress = "return ValidateAmount(this,event)"  id="txtpriceofshare"/></td><td><input type="text" class="form-control"  onkeypress = "return ValidateAmount(this,event)"  id="txtCAmount"/></td>';
//    newRow5.append(cols5);

//    var newRow6 = $("<tr>");
//    var cols6 = "";
//    cols6 += '<td style="text-align:center;display:none"">7</td><td colspan="3">PAID UP CAPITAL</td>';
//    newRow6.append(cols6);
//    var newRow7 = $("<tr>");
//    var cols7 = "";
//    cols7 += '<td  class="hidden">8<td>Number Of Shares</td><td>Price Of Each Share</td><td>Amount</td>';
//    newRow7.append(cols7);
//    var newRow8 = $("<tr>");
//    var cols8 = "";
//    cols8 += '<td  class="hidden">9<td><input type="text" class="form-control"  onkeypress="return IsNumeric(event)" id="txtnoofshare"/></td><td><input type="text" class="form-control"  onkeypress = "return ValidateAmount(this,event)"  id="txtpriceofshare"/></td><td><input type="text" class="form-control"  onkeypress = "return ValidateAmount(this,event)"  id="txtCAmount"/></td>';
//    newRow8.append(cols8);  
   
    
//    $("table.order-list.Capital").append(newRow);
//    $("table.order-list.Capital").append(newRow1);
//    $("table.order-list.Capital").append(newRow2);
//    $("table.order-list.Capital").append(newRow3);
//    $("table.order-list.Capital").append(newRow4);
//    $("table.order-list.Capital").append(newRow5);
//    $("table.order-list.Capital").append(newRow6);
//    $("table.order-list.Capital").append(newRow7);
//    $("table.order-list.Capital").append(newRow8);

//}

// End of Saving Basic Business Info//